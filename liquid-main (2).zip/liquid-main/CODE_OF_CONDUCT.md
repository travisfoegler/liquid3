# Code of Conduct

This project and everyone who participates in it is governed by our [Code of Conduct](https://www.merckgroup.com/company/responsibility/en/regulations-and-guidelines/code-of-conduct.pdf). By participating, you are expected to uphold this code. Please report unacceptable behavior to [liquid@emdgroup.com](liquid@emdgroup.com).