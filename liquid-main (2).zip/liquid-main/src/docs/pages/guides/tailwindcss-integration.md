---
eleventyNavigation:
  key: Tailwind CSS integration
  parent: Guides
  order: 8
layout: layout.njk
title: Tailwind CSS integration
permalink: guides/tailwindcss-integration/
---


# Tailwind CSS Integration

Liquid bundles a [Tailwind CSS preset](https://tailwindcss.com/docs/presets) which you can use as a base for your own Tailwind CSS configuration:

```js
// tailwind.config.js
const liquidPreset = require('@emdgroup-liquid/liquid/dist/css/tailwind-preset.cjs')

module.exports = {
  presets: [liquidPreset],
}
```

## Previewing the Tailwind config

After you have configured Tailwind with Liquid's preset, you may want to use the awesome [Tailwind Config Viewer](https://www.npmjs.com/package/tailwind-config-viewer) as a dev dependency in your project in order to learn which Tailwind utility classes are available to you.

## Disabling Tailwind’s default configuration

Liquid's Tailwind preset extends Tailwind's [default configuration](https://unpkg.com/browse/tailwindcss@%5E2/stubs/defaultConfig.stub.js) by default. If you want Liquid's preset to **not** extend Tailwind's default configuration, include an empty `presets` key in the preset: 

```js
// tailwind.config.js
const liquidPreset = require('@emdgroup-liquid/liquid/dist/css/tailwind-preset.cjs')
liquidPreset.presets = []

module.exports = {
  presets: [liquidPreset],
}
```

<ld-notice headline="Note" mode="warning">
  Not extending Tailwind's default configuration is the same as completely removing Tailwinds default CSS utility classes.
</ld-notice>

<docs-page-nav prev-href="guides/react-bindings/" next-title="Design tokens" next-href="guides/design-tokens/"></docs-page-nav>
