---
eleventyNavigation:
  key: Terms
layout: layout.njk
title: Terms
permalink: legal/license/
---

# License

©2022 Merck KGaA, Darmstadt, Germany

Unless otherwise indicated, all rights to the Liquid Design System including the visual and/or functional assets, the software and the M-Font (summarized as “Content”) or arising from the same shall remain with Merck KGaA, Darmstadt, Germany. Without the prior written consent of Merck KGaA, Darmstadt, Germany, no permission is given to use, import or deploy published and copyrighted Content from the Liquid Design System to other programs, websites and apps or to use such content in any other way.

The Liquid Design System may also contain or reference patents, proprietary information, technologies, products, processes or other proprietary rights of Merck KGaA, Darmstadt, Germany, and/or other parties. No license to, or right in, any such intellectual property rights, such as trademarks, patents, trade secrets, technologies, products, processes and other proprietary rights of Merck Group of companies and/or other parties is granted or awarded to you.

If the Liquid Design System uses free software that is covered by the licenses of the Affero General Public License, GNU GENERAL PUBLIC LICENSE (GPL), GNU LESSER GENERAL PUBLIC LICENSE (LGPL) or another free license (e.g. BSD License, MIT License, Linux Documentation License, Artistic License, IBM Public License, Ricoh Source Code Public License, Mozilla Public License, Python License, Sun Public License), the use of this software or software libraries shall be governed solely by the terms of such licenses, as amended.

International users must also observe the special provisions under local legislation.

You may obtain a copy of the Terms of Use at [https://liquid.emd.design/liquid/legal/terms/](https://liquid.emd.design/liquid/legal/terms/).
