---
eleventyNavigation:
  key: Getting Started
  parent: Data Visualization
  order: 13
layout: layout.njk
title: Getting Started
tags:
  - Overview
  - Dashboard Anatomy
  - Colors
  - Header Elements
  - 5 Data Visualization Rules
  - Examples
permalink: data-visualization/getting-started/
---

<docs-iframe src="/../data-visualization"></docs-iframe>
