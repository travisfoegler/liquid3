/* eslint-disable @stencil/ban-exported-const-enums */
export enum NavEventType {
  open = 'NAV_OPEN',
  close = 'NAV_CLOSE',
}

export enum SearchEventType {
  open = 'SEARCH_OPEN',
  close = 'SEARCH_CLOSE',
}
