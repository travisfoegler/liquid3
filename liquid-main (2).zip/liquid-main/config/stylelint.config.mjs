import stylelintDeclarationStrictValue from 'stylelint-declaration-strict-value'
import stylelintHighPerformanceAnimation from 'stylelint-high-performance-animation'
import stylelintNoUnsupportedBrowserFeatures from 'stylelint-no-unsupported-browser-features'
import stylelintUseNesting from 'stylelint-use-nesting'
import packageJson from '../package.json' assert { type: 'json' }

export default {
  extends: ['stylelint-config-standard'],
  plugins: [
    stylelintDeclarationStrictValue,
    stylelintHighPerformanceAnimation,
    stylelintNoUnsupportedBrowserFeatures,
    stylelintUseNesting,
  ],
  rules: {
    'rule-empty-line-before': null,
    'value-keyword-case': null,
    'font-family-name-quotes': null,
    'import-notation': null,
    'color-function-notation': null,
    'alpha-value-notation': null,
    'selector-class-pattern': null,
    'function-url-quotes': null,
    'declaration-empty-line-before': null,
    'value-no-vendor-prefix': null,
    'property-no-vendor-prefix': null,
    'custom-property-empty-line-before': null,
    'at-rule-empty-line-before': null,
    'comment-empty-line-before': null,
    'block-no-empty': true,
    'color-hex-length': 'long',
    'color-no-invalid-hex': true,
    'csstools/use-nesting': true,
    'no-descending-specificity': null,
    'no-empty-source': null,
    'plugin/no-unsupported-browser-features': [
      true,
      {
        browsers: packageJson.browserslist,
        ignorePartialSupport: true,
        // Most of the stuff below is QQ browser related.
        ignore: [
          'css-backdrop-filter',
          'css-container-query-units',
          'css-focus-visible',
          'css-marker-pseudo',
          'css-math-functions',
          'css-media-range-syntax',
          'css-nesting',
          'css-not-sel-list',
          'css-scrollbar',
          'css-touch-action',
          'pointer',
          'user-select-none',
          'viewport-unit-variants',
          'word-break',
        ],
      },
    ],
    'plugin/no-low-performance-animation-properties': [
      true,
      {
        ignoreProperties: ['visibility'],
      },
    ],
    'scale-unlimited/declaration-strict-value': [
      ['/color/', 'font-size'],
      {
        ignoreValues: ['inherit', 'transparent', 'currentColor'],
        disableFix: true,
      },
    ],
    'selector-disallowed-list': [
      /(?::?:after|:?:before|:?:first-letter|:?:first-line)[^,]+/,
      // /::slotted\(.+\) .*/,
      // /::slotted\(.+\):(?!:?after|:?before|:?first-letter|:?first-line)/,
      // /::slotted\(.*(?::?:after|:?:before|:?:first-letter|:?:first-line|::slotted|:host).*\)/,
      // /::slotted\([^,]+ [^,]+\)/,
      // /::slotted\([^,]*[>+~][^,]+\)/,
      // /:host\([^,]+ [^,]+\)/,
      // /:host\([^,]*[>+~][^,]+\)/,
      /([^, \n][ \n]*):host/,
    ],
    'selector-no-qualifying-type': null,
    'selector-type-no-unknown': [
      true,
      {
        ignoreTypes: ['/^ld-/', '/^docs-/'],
      },
    ],
    'at-rule-no-unknown': [
      true,
      {
        ignoreAtRules: ['/^define-mixin/', '/^mixin/'],
      },
    ],
    'declaration-block-no-duplicate-properties': [true],
  },
  ignoreFiles: ['**/*.md', '**/*.tsx'],
}
